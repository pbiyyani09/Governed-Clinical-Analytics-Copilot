"""Role-scoped semantic cache backed by ChromaDB + BAAI/bge-small-en-v1.5 embeddings.

Key differentiator: a cache hit from role="clinician" is never served to role="researcher"
even if the NL question is semantically identical. This enforces access-role isolation.

Standard caches (GPTCache, Portkey) have no permission model — this one does.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

from ehrcopilot import config

_chroma_client: Any = None
_collection: Any = None
_embed_model: Any = None


def _get_collection() -> Any:
    global _chroma_client, _collection
    if _collection is not None:
        return _collection

    import chromadb  # type: ignore[import]

    cache_dir = Path("cache/chromadb")
    cache_dir.mkdir(parents=True, exist_ok=True)

    _chroma_client = chromadb.PersistentClient(path=str(cache_dir))
    _collection = _chroma_client.get_or_create_collection(
        name="nl_sql_cache",
        metadata={"hnsw:space": "cosine"},
    )
    return _collection


def _get_embed_model() -> Any:
    global _embed_model
    if _embed_model is not None:
        return _embed_model

    from sentence_transformers import SentenceTransformer  # type: ignore[import]

    _embed_model = SentenceTransformer(config.CACHE_EMBEDDING_MODEL)
    return _embed_model


def _embed(text: str) -> list[float]:
    model = _get_embed_model()
    vec = model.encode(text, normalize_embeddings=True)
    return vec.tolist()


def _nl_hash(question: str, role: str) -> str:
    return hashlib.sha256(f"{role}::{question}".encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def lookup(question: str, role: str) -> dict[str, Any] | None:
    """Return a cached entry if a semantically similar same-role query exists.

    Returns None on miss. Returns the cached entry dict on hit.
    """
    collection = _get_collection()
    embedding = _embed(question)

    results = collection.query(
        query_embeddings=[embedding],
        n_results=1,
        where={"$and": [{"role": {"$eq": role}}, {"db_version": {"$eq": config.DB_VERSION}}]},
        include=["metadatas", "distances", "documents"],
    )

    if not results["ids"] or not results["ids"][0]:
        return None

    distance = results["distances"][0][0]
    similarity = 1.0 - distance  # cosine distance → similarity

    if similarity < config.CACHE_COSINE_THRESHOLD:
        return None

    meta = results["metadatas"][0][0]

    # TTL check
    created_at = float(meta.get("created_at", 0))
    if time.time() - created_at > config.CACHE_TTL_SECONDS:
        return None

    return {
        "sql": meta.get("sql"),
        "answer": meta.get("answer"),
        "similarity": similarity,
        "cached_question": results["documents"][0][0],
    }


def store(
    question: str,
    role: str,
    sql: str,
    answer: str | None = None,
    exec_result: list[dict[str, Any]] | None = None,
) -> None:
    """Store a (question, role, sql) triple in the cache."""
    collection = _get_collection()
    embedding = _embed(question)
    doc_id = _nl_hash(question, role)

    result_hash = (
        hashlib.sha256(json.dumps(exec_result, sort_keys=True).encode()).hexdigest()[:16]
        if exec_result
        else ""
    )

    collection.upsert(
        ids=[doc_id],
        embeddings=[embedding],
        documents=[question],
        metadatas=[
            {
                "role": role,
                "sql": sql,
                "answer": answer or "",
                "result_hash": result_hash,
                "created_at": time.time(),
                "db_version": config.DB_VERSION,
            }
        ],
    )


def invalidate_by_db_version() -> int:
    """Delete all entries whose db_version doesn't match the current config.DB_VERSION.

    Returns the number of entries deleted.
    """
    collection = _get_collection()
    results = collection.get(
        where={"db_version": {"$ne": config.DB_VERSION}},
        include=["metadatas"],
    )
    ids = results.get("ids", [])
    if ids:
        collection.delete(ids=ids)
    return len(ids)


def cache_stats() -> dict[str, Any]:
    """Return basic cache statistics."""
    collection = _get_collection()
    count = collection.count()
    return {
        "total_entries": count,
        "db_version": config.DB_VERSION,
        "cosine_threshold": config.CACHE_COSINE_THRESHOLD,
        "ttl_seconds": config.CACHE_TTL_SECONDS,
        "embedding_model": config.CACHE_EMBEDDING_MODEL,
    }
